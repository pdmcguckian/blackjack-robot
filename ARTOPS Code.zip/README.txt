ARTOPS: a Blackjack playing robot
Created by Oliver Colebourne & Patrick McGuckian
11.12.2019

To run out robot we run the initialise.sh file (in Rapsberry Pi folder) with bash. 
This first goes into the virtual environment we are using then sets the cursor to automatically time out.

The bash file then runs main.py, the main code of the project.